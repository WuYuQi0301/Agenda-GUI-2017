/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../include/ui_/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[37];
    char stringdata0[441];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 10), // "quitSystem"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 12), // "loginSucceed"
QT_MOC_LITERAL(4, 36, 9), // "loginFail"
QT_MOC_LITERAL(5, 46, 12), // "registerFail"
QT_MOC_LITERAL(6, 59, 15), // "registerSucceed"
QT_MOC_LITERAL(7, 75, 9), // "CMsucceed"
QT_MOC_LITERAL(8, 85, 6), // "CMfail"
QT_MOC_LITERAL(9, 92, 9), // "ADsucceed"
QT_MOC_LITERAL(10, 102, 6), // "ADfail"
QT_MOC_LITERAL(11, 109, 10), // "AMPsucceed"
QT_MOC_LITERAL(12, 120, 9), // "showLogin"
QT_MOC_LITERAL(13, 130, 12), // "showRegister"
QT_MOC_LITERAL(14, 143, 11), // "showWelcome"
QT_MOC_LITERAL(15, 155, 14), // "receiveCommand"
QT_MOC_LITERAL(16, 170, 7), // "command"
QT_MOC_LITERAL(17, 178, 11), // "verifyLogin"
QT_MOC_LITERAL(18, 190, 8), // "userName"
QT_MOC_LITERAL(19, 199, 8), // "password"
QT_MOC_LITERAL(20, 208, 14), // "verifyRegister"
QT_MOC_LITERAL(21, 223, 13), // "buildComboBox"
QT_MOC_LITERAL(22, 237, 19), // "verifyCreateMeeting"
QT_MOC_LITERAL(23, 257, 6), // "string"
QT_MOC_LITERAL(24, 264, 6), // "_title"
QT_MOC_LITERAL(25, 271, 10), // "_startDate"
QT_MOC_LITERAL(26, 282, 8), // "_endDate"
QT_MOC_LITERAL(27, 291, 14), // "vector<string>"
QT_MOC_LITERAL(28, 306, 2), // "pa"
QT_MOC_LITERAL(29, 309, 18), // "verifyAddMeetingPa"
QT_MOC_LITERAL(30, 328, 11), // "_paticpator"
QT_MOC_LITERAL(31, 340, 21), // "verifyRemoveMeetingPa"
QT_MOC_LITERAL(32, 362, 12), // "_paticipator"
QT_MOC_LITERAL(33, 375, 22), // "verifyQueryMeetingTime"
QT_MOC_LITERAL(34, 398, 9), // "startDate"
QT_MOC_LITERAL(35, 408, 7), // "endDate"
QT_MOC_LITERAL(36, 416, 24) // "on_comfirmButton_clicked"

    },
    "MainWindow\0quitSystem\0\0loginSucceed\0"
    "loginFail\0registerFail\0registerSucceed\0"
    "CMsucceed\0CMfail\0ADsucceed\0ADfail\0"
    "AMPsucceed\0showLogin\0showRegister\0"
    "showWelcome\0receiveCommand\0command\0"
    "verifyLogin\0userName\0password\0"
    "verifyRegister\0buildComboBox\0"
    "verifyCreateMeeting\0string\0_title\0"
    "_startDate\0_endDate\0vector<string>\0"
    "pa\0verifyAddMeetingPa\0_paticpator\0"
    "verifyRemoveMeetingPa\0_paticipator\0"
    "verifyQueryMeetingTime\0startDate\0"
    "endDate\0on_comfirmButton_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      13,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  124,    2, 0x06 /* Public */,
       3,    0,  125,    2, 0x06 /* Public */,
       4,    0,  126,    2, 0x06 /* Public */,
       5,    0,  127,    2, 0x06 /* Public */,
       6,    0,  128,    2, 0x06 /* Public */,
       7,    0,  129,    2, 0x06 /* Public */,
       8,    0,  130,    2, 0x06 /* Public */,
       9,    0,  131,    2, 0x06 /* Public */,
      10,    0,  132,    2, 0x06 /* Public */,
      11,    0,  133,    2, 0x06 /* Public */,
      12,    0,  134,    2, 0x06 /* Public */,
      13,    0,  135,    2, 0x06 /* Public */,
      14,    0,  136,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      15,    1,  137,    2, 0x08 /* Private */,
      17,    2,  140,    2, 0x08 /* Private */,
      20,    4,  145,    2, 0x08 /* Private */,
      21,    0,  154,    2, 0x08 /* Private */,
      22,    4,  155,    2, 0x08 /* Private */,
      29,    2,  164,    2, 0x08 /* Private */,
      31,    2,  169,    2, 0x08 /* Private */,
      33,    2,  174,    2, 0x08 /* Private */,
      36,    0,  179,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   18,   19,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,    2,    2,    2,    2,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 23, 0x80000000 | 23, 0x80000000 | 23, 0x80000000 | 27,   24,   25,   26,   28,
    QMetaType::Void, 0x80000000 | 23, 0x80000000 | 23,   24,   30,
    QMetaType::Void, 0x80000000 | 23, 0x80000000 | 23,   24,   32,
    QMetaType::Void, 0x80000000 | 23, 0x80000000 | 23,   34,   35,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->quitSystem(); break;
        case 1: _t->loginSucceed(); break;
        case 2: _t->loginFail(); break;
        case 3: _t->registerFail(); break;
        case 4: _t->registerSucceed(); break;
        case 5: _t->CMsucceed(); break;
        case 6: _t->CMfail(); break;
        case 7: _t->ADsucceed(); break;
        case 8: _t->ADfail(); break;
        case 9: _t->AMPsucceed(); break;
        case 10: _t->showLogin(); break;
        case 11: _t->showRegister(); break;
        case 12: _t->showWelcome(); break;
        case 13: _t->receiveCommand((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 14: _t->verifyLogin((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 15: _t->verifyRegister((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3])),(*reinterpret_cast< const QString(*)>(_a[4]))); break;
        case 16: _t->buildComboBox(); break;
        case 17: _t->verifyCreateMeeting((*reinterpret_cast< const string(*)>(_a[1])),(*reinterpret_cast< const string(*)>(_a[2])),(*reinterpret_cast< const string(*)>(_a[3])),(*reinterpret_cast< const vector<string>(*)>(_a[4]))); break;
        case 18: _t->verifyAddMeetingPa((*reinterpret_cast< const string(*)>(_a[1])),(*reinterpret_cast< const string(*)>(_a[2]))); break;
        case 19: _t->verifyRemoveMeetingPa((*reinterpret_cast< const string(*)>(_a[1])),(*reinterpret_cast< const string(*)>(_a[2]))); break;
        case 20: _t->verifyQueryMeetingTime((*reinterpret_cast< const string(*)>(_a[1])),(*reinterpret_cast< const string(*)>(_a[2]))); break;
        case 21: _t->on_comfirmButton_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::quitSystem)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::loginSucceed)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::loginFail)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::registerFail)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::registerSucceed)) {
                *result = 4;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::CMsucceed)) {
                *result = 5;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::CMfail)) {
                *result = 6;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::ADsucceed)) {
                *result = 7;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::ADfail)) {
                *result = 8;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::AMPsucceed)) {
                *result = 9;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::showLogin)) {
                *result = 10;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::showRegister)) {
                *result = 11;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::showWelcome)) {
                *result = 12;
                return;
            }
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 22;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::quitSystem()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}

// SIGNAL 1
void MainWindow::loginSucceed()
{
    QMetaObject::activate(this, &staticMetaObject, 1, Q_NULLPTR);
}

// SIGNAL 2
void MainWindow::loginFail()
{
    QMetaObject::activate(this, &staticMetaObject, 2, Q_NULLPTR);
}

// SIGNAL 3
void MainWindow::registerFail()
{
    QMetaObject::activate(this, &staticMetaObject, 3, Q_NULLPTR);
}

// SIGNAL 4
void MainWindow::registerSucceed()
{
    QMetaObject::activate(this, &staticMetaObject, 4, Q_NULLPTR);
}

// SIGNAL 5
void MainWindow::CMsucceed()
{
    QMetaObject::activate(this, &staticMetaObject, 5, Q_NULLPTR);
}

// SIGNAL 6
void MainWindow::CMfail()
{
    QMetaObject::activate(this, &staticMetaObject, 6, Q_NULLPTR);
}

// SIGNAL 7
void MainWindow::ADsucceed()
{
    QMetaObject::activate(this, &staticMetaObject, 7, Q_NULLPTR);
}

// SIGNAL 8
void MainWindow::ADfail()
{
    QMetaObject::activate(this, &staticMetaObject, 8, Q_NULLPTR);
}

// SIGNAL 9
void MainWindow::AMPsucceed()
{
    QMetaObject::activate(this, &staticMetaObject, 9, Q_NULLPTR);
}

// SIGNAL 10
void MainWindow::showLogin()
{
    QMetaObject::activate(this, &staticMetaObject, 10, Q_NULLPTR);
}

// SIGNAL 11
void MainWindow::showRegister()
{
    QMetaObject::activate(this, &staticMetaObject, 11, Q_NULLPTR);
}

// SIGNAL 12
void MainWindow::showWelcome()
{
    QMetaObject::activate(this, &staticMetaObject, 12, Q_NULLPTR);
}
QT_END_MOC_NAMESPACE
